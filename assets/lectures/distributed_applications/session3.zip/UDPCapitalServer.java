import java.net.*;

public class UDPCapitalServer {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		DatagramSocket server = new DatagramSocket(9876);
		byte[] recvData = new byte[1024];
		byte[] sendData = new byte[1024];
		
		while(true) {
			DatagramPacket dp = new DatagramPacket(recvData, recvData.length);
			server.receive(dp);
			String data = new String(dp.getData());
			InetAddress ipAddr = dp.getAddress();
			int port = dp.getPort();
			String reply = data.toUpperCase();
			sendData = reply.getBytes();
			DatagramPacket dpp = new DatagramPacket(sendData, sendData.length,ipAddr, port);
			server.send(dpp);
		}
	}

}
