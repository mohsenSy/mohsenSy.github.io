import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.*;

public class UDPCapitalClient {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		BufferedReader inFroUser = new BufferedReader(new InputStreamReader(System.in));
		DatagramSocket client = new DatagramSocket();
		InetAddress ip = InetAddress.getByName("localhost");
		byte[] sendData = new byte[1024];
		byte[] recvData = new byte[1024];
		String data = inFroUser.readLine();
		sendData = data.getBytes();
		DatagramPacket dp = new DatagramPacket(sendData, sendData.length, ip, 9876);
		client.send(dp);
		DatagramPacket dpp = new DatagramPacket(recvData, recvData.length);
		client.receive(dpp);
		String reply = new String(dpp.getData());
		System.out.println("Server replied with : " + reply);
		client.close();
	}

}
