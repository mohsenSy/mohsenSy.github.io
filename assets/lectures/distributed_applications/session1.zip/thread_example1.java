
public class Example1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		JavaThread gt1 = new JavaThread("Hello");
		JavaThread gt2 = new JavaThread("World");
		gt1.start();
		gt2.start();
		
		System.out.println("main thread");

	}

}

class JavaThread extends Thread {
	String word;
	public JavaThread(String s) {
		word = s;
	}
	
	public void run() {
		try {
			for(;;) {
				System.out.println(word);
				sleep(1000);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
