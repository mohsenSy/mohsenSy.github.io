
public class Count {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CountThread th1 = new Thread3(0,10);
		CountThread th2 = new Thread3(10,20);
		th1.start();
		th2.start();
		try {
			th1.join();
			th2.join();
		} catch (InterruptedException e) {
			// TODO: handle exception
		}
		
		System.out.println("Main thread finished");
		

	}

}

class CountThread extends Thread {
	private int num1, num2;
	public Thread3(int n1, int n2) {
		num1 = n1;
		num2 = n2;
	}
	public void run() {
		for (int i = num1; i<num2;i++) {
			System.out.println(i);
		}
	}
}
