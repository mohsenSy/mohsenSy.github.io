import java.rmi.Naming ;
import java.rmi.RemoteException ;
import java.rmi.NotBoundException ;
import java.net.MalformedURLException ;
 
public class Client
{
   public final static String HOST = "localhost" ;
 
   public static void main (String args[])
   {
      try
      {
          String objectName = "rmi://" + HOST + "/HelloWorld" ;
          
         Hello myObject = (Hello) Naming.lookup(objectName);
 
         System.out.println(myObject.getHelloMessage());
      }
      catch (RemoteException e)
      {   e.printStackTrace();   }
      catch (NotBoundException e)
      {   e.printStackTrace();   }
      catch (MalformedURLException e)
      {   e.printStackTrace();   }
   }
}