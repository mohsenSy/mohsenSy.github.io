// RMI Server 

import java.rmi.RemoteException ;
import java.rmi.Naming ;
import java.net.MalformedURLException ;

public class Server 
{
   final static String HOST = "localhost" ;

   public static void main (String args[])
   {
      try
      {
         HelloImpl myObject = new HelloImpl();
         String objectName = "rpc://" + HOST + "/HelloWorld" ;
         Naming.rebind(objectName,myObject);
         System.out.println("Binding Complete .....");
      }
      catch (RemoteException e)
      {   e.printStackTrace();   }
      catch (MalformedURLException e)
      {   e.printStackTrace();   }

   }
}