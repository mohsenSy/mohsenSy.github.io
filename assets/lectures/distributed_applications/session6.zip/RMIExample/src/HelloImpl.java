
import java.rmi.RemoteException ;
import java.rmi.server.UnicastRemoteObject ;

public class HelloImpl extends UnicastRemoteObject implements Hello
{

public HelloImpl () throws RemoteException 
   {   }

   public String getHelloMessage() throws RemoteException
   {
	  System.out.println("I am running at RMI Server");
      return "Hello From RMI" ;
   }
}
