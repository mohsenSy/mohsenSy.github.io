package session5;

import java.io.*;

public class IOExample {

	public static void main(String[] args)throws IOException {
		// TODO Auto-generated method stub
		// Read Character from Console Input
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		char c = (char)br.read();
		System.out.println(c);

		// Read a String
		String s = br.readLine();
		System.out.println(s);
		
		// Read from a file
		FileInputStream fis = new FileInputStream("test.txt");
		br = new BufferedReader(new InputStreamReader(fis));
		String text = br.readLine();
		System.out.println(text);
		br.close();
		
		// Read from a file using FileReader
		FileReader fr = new FileReader("test.txt");
		char[] fileData = new char[1024];
		int bytes = fr.read(fileData);
		System.out.println("Read " + bytes + " From file");
		System.out.println(fileData);
		fr.close();
		
		// Write to a file
		FileWriter fw = new FileWriter("t.txt");
		String data = "Write this to the file";
		fw.write(data);
		fw.close();
	}

}
