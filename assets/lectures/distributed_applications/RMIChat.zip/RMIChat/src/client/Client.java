package client;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import common.IClient;

public class Client extends UnicastRemoteObject implements IClient {

	private String name;
	private String password;
	
	protected Client() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getName() throws RemoteException {
		// TODO Auto-generated method stub
		
		return name;
	}

	@Override
	public String getPassword() throws RemoteException {
		// TODO Auto-generated method stub
		return password;
	}

	@Override
	public void setName(String name) throws RemoteException {
		// TODO Auto-generated method stub
		this.name = name;
		
	}

	@Override
	public void setPassword(String password) throws RemoteException {
		// TODO Auto-generated method stub
		this.password = password;
		
	}
	
	@Override
	public void receive(String message)throws RemoteException {
		System.out.println(message);
	}

}
