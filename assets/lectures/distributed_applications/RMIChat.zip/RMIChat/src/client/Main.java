package client;

import java.rmi.NotBoundException;

public class Main {

	public static void main(String[] args) throws NotBoundException {
		// TODO Auto-generated method stub
		ClientManager cm = new ClientManager();
		cm.run();

	}

}
