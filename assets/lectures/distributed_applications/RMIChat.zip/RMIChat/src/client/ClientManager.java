package client;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import com.sun.xml.internal.ws.resources.SenderMessages;

import common.IChat;

public class ClientManager {
	
	private IChat chat;
	private Client client;
	private String PROMPT;
	public ClientManager() {
		try {
			PROMPT = "user> ";
			chat = (IChat)Naming.lookup("rmi://localhost/chat");
			client = null;
		} catch (MalformedURLException | RemoteException | NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}
	}
	
	public ClientManager(String prompt) {
		try {
			PROMPT = prompt;
			chat = (IChat)Naming.lookup("rmi://localhost/chat");
			client = new Client();
		} catch (MalformedURLException | RemoteException | NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}
	}
	
	public void run() throws NotBoundException {
		writeString("Welcome to our chat client");
		writeString("If you already have an account then please login, otherwise regisetr to be able to use the service");
		while(true) {
			writeString("Enter your choice (r) for register, (l) for login");
			try {
				String choice = readString();
				if (choice.equalsIgnoreCase("r") || choice.equalsIgnoreCase("register") ) {
					register();
					if (login()) {
						writeString("You are registered and logged in");
						break;
					}
					else {
						writeString("Wrong user name or password");
						client = null;
					}
				}
				if (choice.equalsIgnoreCase("l") || choice.equalsIgnoreCase("login") ) {
					if (login()) {
						writeString("You are logged in");
						break;
					}
					else {
						writeString("Wrong user name or password");
						client = null;
					}
				}
				else {
					writeString("Invalid choice");
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		
		// Now logged in, we can start sending and receiving messages
		writeString("Enter your message, (e) exit to finish");
		while(true) {
			try {
				String msg = readString();
				if (msg.equalsIgnoreCase("e") || msg.equalsIgnoreCase("exit")) {
					break;
				}
				sendMessage(msg);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	private void sendMessage(String msg) {
		if (client == null) {
			writeString("Please login first");
			return;
		}
		try {
			chat.sendToAll(client, msg);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			try {

				IChat backup = (IChat)Naming.lookup("rmi://localhost/backup");
				backup.sendToAll(client, msg);	
			} catch (Exception e2) {
				// TODO: handle exception
				System.exit(1);
			}
		}
	}

	private void createClient() {
		// Read the user name
		try {
			writeString("Enter your name");
			String name = readString();
			writeString("Enter your password");
			String password = readString();
			client = new Client();
			client.setName(name);
			client.setPassword(password);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}	
	}
	
	public String register() {
		createClient();
		try {
			return chat.register(client);	
		} catch (Exception e) {
			// TODO: handle exception
			try {

				IChat backup = (IChat)Naming.lookup("rmi://localhost/backup");
				return backup.register(client);	
			} catch (Exception e2) {
				// TODO: handle exception
				System.exit(1);
			}

		}
		return "";
		
	}
	
	public Boolean login() {
		if (client == null) {
			createClient();	
		}
		
		try {
			return chat.login(client);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			try {

				IChat backup = (IChat)Naming.lookup("rmi://localhost/backup");
				return backup.login(client);	
			} catch (Exception e2) {
				// TODO: handle exception
				System.exit(1);
			}
		}
		return false;
	}
	
	private String readString() throws IOException {
		prompt();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		return br.readLine();
	}
	
	private void writeString(String msg) {
		System.out.println(msg);
	}
	
	private void prompt() {
		System.out.print(PROMPT);
	}
}
