package server;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.security.MessageDigest;
import java.util.ArrayList;

import common.IChat;
import common.IClient;

public class Chata extends UnicastRemoteObject implements IChat {

	private ArrayList<IClient> clients;
	protected Chata() throws RemoteException {
		super();
		clients = new ArrayList<IClient>();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String register(IClient client) throws RemoteException, IOException, NotBoundException {
		// TODO Auto-generated method stub
		// Create a file named after the user's name and put password inside file
		// TODO Hash password before storage
		String name = client.getName();
		String password = client.getPassword();
		// Check if the name starts with a letter less than or equal 'm'
		if(name.charAt(0) <= 'm') {
			// TODO handle if the user name already exists before overwriting the file
			FileWriter fw = new FileWriter("chat_a/" + name);
			fw.write(password);
			fw.close();			
		}
		else {
			// Register in another server
			return register_b(client);
		}
		
		register_backup(client);
		return "Welcome " + name + ", you are registered now";
	}

	private void register_backup(IClient client) throws NotBoundException, IOException {
		// TODO Auto-generated method stub
		IChat chat = (IChat)Naming.lookup("rmi://localhost/backup");
		chat.register(client);
		
	}

	private String register_b(IClient client) throws RemoteException, IOException, NotBoundException {
		// TODO Auto-generated method stub
		IChat chat_b = (IChat)Naming.lookup("rmi://localhost/chatb");
		return chat_b.register(client);
	}

	@Override
	public Boolean login(IClient client) throws RemoteException, MalformedURLException, NotBoundException {
		// TODO Auto-generated method stub
		// Retrieve the user's name and password then compare
		String name = client.getName();
		String password = client.getPassword();
		login_backup(client);
		if(name.charAt(0) <= 'm') {
			// TODO hash password before comparison
			// Read the password from the file
			BufferedReader br = null;
			try {
				br = new BufferedReader(new FileReader("chat_a/" + name));
				String pass = br.readLine();
				if(pass.equals(password)) {
					addClient(client);
					return true;
				}
				// Wrong password
				return false;
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				// No user with this name
				return false;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				// Cannot read password
				return false;
			}
			finally {
				try {
					if (br != null) {
						br.close();	
					}
				} catch (IOException e) {
					
				}
			}
		}else {
			return login_b(client);
		}
	}
	
	private void login_backup(IClient client) throws MalformedURLException, RemoteException, NotBoundException {
		// TODO Auto-generated method stub
		IChat chat = (IChat)Naming.lookup("rmi://localhost/backup");
		chat.login(client);
		
	}

	private Boolean login_b(IClient client) throws MalformedURLException, RemoteException, NotBoundException {
		// TODO Auto-generated method stub
		IChat chat_b = (IChat)Naming.lookup("rmi://localhost/chatb");
		return chat_b.login(client);
	}

	private void addClient(IClient client) {
		clients.add(client);
	}

	@Override
	public Boolean sendToAll(IClient client, String msg) throws RemoteException, MalformedURLException, NotBoundException {
		// TODO Auto-generated method stub
		for (int i = 0;i< clients.size();i++) {
			try {
				IClient c = clients.get(i);
				if (!c.getName().equals(client.getName())) {
					c.receive(client.getName() + ": " + msg);	
					
				}				
			} catch (Exception e) {
				// TODO: handle exception
				clients.remove(i);
			}
			
		}
		return send_b(client, msg);
	}

	private Boolean send_b(IClient client, String msg) throws MalformedURLException, RemoteException, NotBoundException {
		// TODO Auto-generated method stub
		IChat chat_b = (IChat)Naming.lookup("rmi://localhost/chatb");
		return chat_b.sendToAll(client, msg);
	}

}
