package server;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;

public class MainB {

	public static void main(String[] args) throws RemoteException, MalformedURLException {
		// TODO Auto-generated method stub
		
		Chatb chat = new Chatb();
		Naming.rebind("rmi://localhost/chatb", chat);
		System.out.println("Second server is up and running");

	}

}
