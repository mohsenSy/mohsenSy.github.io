package server;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

import common.IChat;
import common.IClient;

public class ChatBackup extends UnicastRemoteObject implements IChat {

	private ArrayList<IClient> clients;
	protected ChatBackup() throws RemoteException, MalformedURLException {
		super();
		clients = new ArrayList<IClient>();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String register(IClient client) throws RemoteException, IOException {
		// TODO Auto-generated method stub
		// Create a file named after the user's name and put password inside file
		// TODO Hash password before storage
		String name = client.getName();
		String password = client.getPassword();
		// TODO handle if the user name already exists before overwriting the file
		FileWriter fw = new FileWriter("chat_backup/" + name);
		fw.write(password);
		fw.close();			
		
		return "Welcome " + name + ", you are registered now";
	}
	
	@Override
	public Boolean login(IClient client) throws RemoteException {
		// TODO Auto-generated method stub
		// Retrieve the user's name and password then compare
		String name = client.getName();
		String password = client.getPassword();
		// TODO hash password before comparison
		// Read the password from the file
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("chat_backup/" + name));
			String pass = br.readLine();
			if(pass.equals(password)) {
				addClient(client);
				return true;
			}
			// Wrong password
			return false;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			// No user with this name
			return false;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// Cannot read password
			return false;
		}
		finally {
			try {
				if (br != null) {
					br.close();	
				}
			} catch (IOException e) {
				
			}
		}
	}
	
	private void addClient(IClient client) {
		clients.add(client);
	}

	@Override
	public Boolean sendToAll(IClient client, String msg) throws RemoteException {
		// TODO Auto-generated method stub
		for (int i = 0;i< clients.size();i++) {
			try {
				IClient c = clients.get(i);
				if (!c.getName().equals(client.getName())) {
					c.receive(client.getName() + ": " + msg);	
					
				}				
			} catch (Exception e) {
				// TODO: handle exception
				clients.remove(i);
			}
			
		}
		return true;
	}

}
