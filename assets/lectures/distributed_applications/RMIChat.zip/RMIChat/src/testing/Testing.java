package testing;

public class Testing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s = "mohsen";
		char c = s.charAt(0);
		System.out.println(c>'n');

	}

}
