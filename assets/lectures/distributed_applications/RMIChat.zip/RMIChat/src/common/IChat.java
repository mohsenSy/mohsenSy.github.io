package common;

import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.*;

public interface IChat extends Remote {
	
	// A method to register new user
	public String register(IClient client) throws RemoteException, IOException, NotBoundException;
	
	// A method to login a user
	public Boolean login(IClient client) throws RemoteException, MalformedURLException, NotBoundException;
	
	// A method to send to all users
	public Boolean sendToAll(IClient client, String msg)throws RemoteException, MalformedURLException, NotBoundException;

}
