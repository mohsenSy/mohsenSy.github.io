package common;

import java.rmi.*;

public interface IClient extends Remote {
	// A method to get client name
	public String getName()throws RemoteException;
	
	// A method to get client password
	public String getPassword()throws RemoteException;
	
	// A method to set client name
	public void setName(String name)throws RemoteException;
	
	// A method to set client password
	public void setPassword(String password)throws RemoteException;
	
	// A method to print the received message
	public void receive(String message)throws RemoteException;
}
