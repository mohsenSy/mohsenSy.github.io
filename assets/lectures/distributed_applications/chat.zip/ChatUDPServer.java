package session4;

import java.io.*;
import java.net.*;
import java.util.ArrayList;

import sun.nio.ch.DatagramSocketAdaptor;

class Client {
	private String name;
	private InetAddress ip;
	private int port;
	
	public Client(String name, InetAddress ip, int port) {
		this.name = name;
		this.ip = ip;
		this.port = port;
	}
}



public class ChatUDPServer {
	
	private static DatagramSocket server;
	private static ArrayList<Client> clients;
	
	public static void main(String[] args)throws SocketException,IOException {
		// TODO Auto-generated method stub
		clients = new ArrayList<Client>();
		server = new DatagramSocket(9120);
		byte[] recvData = new byte[1024];
		DatagramPacket dp = new DatagramPacket(recvData, recvData.length);
		server.receive(dp);
		handleClient(dp);
	}

	private static void handleClient(DatagramPacket dp)throws IOException{
		// TODO Auto-generated method stub
		String data = new String(dp.getData());
		String type = data.substring(0, data.indexOf(' '));
		String message = data.substring(data.indexOf(' ') + 1);
		if(type.equals("login")) {
			addClient(message, dp.getAddress(),dp.getPort());
		}
		
	}

	private static void addClient(String name, InetAddress address, int port)throws IOException {
		// TODO Auto-generated method stub
		clients.add(new Client(name, address, port));
		sendResponse("Welcome " + name, address, port);
	}

	private static void sendResponse(String message, InetAddress address, int port)throws IOException {
		// TODO Auto-generated method stub
		byte[] sendData = new byte[1024];
		sendData = message.getBytes();
		DatagramPacket dp = new DatagramPacket(sendData, sendData.length,address, port);
		server.send(dp);
	}

}
