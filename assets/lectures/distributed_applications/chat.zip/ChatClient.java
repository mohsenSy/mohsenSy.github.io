package session4;

import java.io.*;
import java.net.*;

class Receiver extends Thread {
	private DatagramSocket client;
	public Receiver(DatagramSocket client) {
		this.client = client;
	}
	
	public void run() {
		while(true) {
			byte[] recvData = new byte[1024];
			DatagramPacket dp = new DatagramPacket(recvData, recvData.length);
			try {
				client.receive(dp);
				String res = new String(dp.getData());
				System.out.println(res);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
}

public class ChatClient {
	private static DatagramSocket client; 

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		client = new DatagramSocket();
		Receiver recvThread = new Receiver(client);
		recvThread.start();
		byte[] recvData = new byte[1024];
		byte[] sendData = new byte[1024];
		InetAddress ip = InetAddress.getByName("localhost");
		int port = 9145;
		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
		while(true) {
			String choice = inFromUser.readLine();
			if(choice.equals("login")) {
				String name = inFromUser.readLine();
				login(name, ip, port);
			}
			else if(choice.equals("msg")) {
				String message = inFromUser.readLine();
				msg(message, ip, port);
			}
			else {
				System.out.println("Unkown choice " + choice);
			}
		}
	}

	private static void msg(String message, InetAddress ip, int port) throws IOException {
		// TODO Auto-generated method stub
		byte[] sendData = new byte[1024];
		String messageS = "msg " + message;
		sendData = messageS.getBytes();
		DatagramPacket dp = new DatagramPacket(sendData, sendData.length,ip, port);
		client.send(dp);
	}

	private static void login(String name, InetAddress ip, int port) throws IOException {
		// TODO Auto-generated method stub
		byte[] sendData = new byte[1024];
		String message = "login " + name;
		sendData = message.getBytes();
		DatagramPacket dp = new DatagramPacket(sendData, sendData.length,ip, port);
		client.send(dp);
	}

}
