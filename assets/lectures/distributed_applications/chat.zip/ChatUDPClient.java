package session4;

import java.io.*;
import java.net.*;

public class ChatUDPClient {

	public static void main(String[] args)throws SocketException,UnknownHostException,IOException {
		// TODO Auto-generated method stub
		
		DatagramSocket client = new DatagramSocket();
		String message = "login mohsen";
		byte[] sendData = new byte[1024];
		sendData = message.getBytes();
		InetAddress ip = InetAddress.getByName("localhost");
		DatagramPacket dp = new DatagramPacket(sendData, sendData.length,ip,9120);
		client.send(dp);
		byte[] recvData = new byte[1024];
		DatagramPacket dpp = new DatagramPacket(recvData, recvData.length);
		client.receive(dpp);
		String reply = new String(dpp.getData());
		System.out.println(reply);
	}

}
