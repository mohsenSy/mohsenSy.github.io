package session4;

import java.io.IOException;
import java.net.*;
import java.util.ArrayList;

import com.sun.corba.se.spi.activation.Server;
import com.sun.xml.internal.ws.client.ClientSchemaValidationTube;

class Client1 {
	
	private String name;
	private InetAddress ip;
	private int port;

	public Client1(String name, InetAddress ip, int port) {
		this.name = name;
		this.ip = ip;
		this.port = port;
	}
	public InetAddress getIp() {
		return ip;
	}
	public int getPort() {
		return port;
	}
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
}

public class ChatServer {
	private static ArrayList<Client1> clients;
	private static DatagramSocket server;

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		server = new DatagramSocket(9145);
		//byte[] sendData = new byte[1024];
		clients = new ArrayList<Client1>();
		while(true) {
			byte[] recvData = new byte[1024];
			DatagramPacket dp = new DatagramPacket(recvData, recvData.length);
			server.receive(dp);
			//System.out.println("Received from ip " + dp.getAddress() + " and port " + dp.getPort());
			handleClient(dp);
			
		}

	}
	private static void addClient(String name, InetAddress ip, int port) {
		//System.out.println("Added a new client with name " + name);
		clients.add(new Client1(name, ip, port));
	}
	private static void handleClient(DatagramPacket dp) throws IOException {
		String data = new String(dp.getData());
		String type = data.substring(0, data.indexOf(' '));
		String message = data.substring(data.indexOf(' ') + 1);
		if (type.equals("login")) {
			addClient(message, dp.getAddress(), dp.getPort());
		}else if(type.equals("msg")) {
			//System.out.println("Sending message " + message);
			sendMsg(message, dp.getAddress(), dp.getPort());
		}
		else {
			System.out.println("Unknown type " + type);
		}
	}
	private static void sendMsg(String message, InetAddress address, int port) throws IOException {
		// TODO Auto-generated method stub
		// First get the user name
		String name = new String();
		name = getUserByAddress(address, port);
		if (name == null) {
			System.out.println("No user found");
			sendResponse("error: please login first", address, port);
			return;
		}
		System.out.println("Sending to all clients");
		String msg = name + ": " + message;
		System.out.println(msg + " To all clients");
		SendToAllClients(message,name);
		
	}
	private static void SendToAllClients(String message, String name) throws IOException {
		// TODO Auto-generated method stub
		// name = "mohsen";
		String data = name + ": " + message;
		//System.out.println("All clients " + data);
		for(int i = 0;i<clients.size();i++) {
			String currentName = clients.get(i).getName();
			boolean same = name.equals(currentName);
			if(same == false) {
				sendResponse(data, clients.get(i).getIp(),clients.get(i).getPort());
			}
		}
		
	}
	private static void sendResponse(String string, InetAddress address, int port) throws IOException {
		// TODO Auto-generated method stub
		DatagramPacket dp = new DatagramPacket(string.getBytes(), string.getBytes().length,address,port);
		//System.out.println("Sending " + string);
		server.send(dp);
		
	}
	private static String getUserByAddress(InetAddress address, int port) {
		// TODO Auto-generated method stub
		for(int i = 0;i<clients.size();i++) {
			if(clients.get(i).getIp().equals(address) && clients.get(i).getPort() == port) {
				//String name = clients.get(i).getName();
				return clients.get(i).getName();
			}
		}
		return null;
	}

}
