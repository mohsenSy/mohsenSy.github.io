import java.io.*;
import java.net.*;

public class TCPCapitalServer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			String clientSentence;
			String capitalizedSentence;
			@SuppressWarnings("resource")
			ServerSocket server = new ServerSocket(1234);
			while(true) {
				Socket client = server.accept();
				Capital c = new Capital(client);
				c.start();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

class Capital extends Thread {
	private Socket client;
	public Capital(Socket client) {
		this.client = client;
	}
	public void run() {
		try {
			BufferedReader inFromClient = new BufferedReader(new InputStreamReader(client.getInputStream()));
			DataOutputStream outToClient = new DataOutputStream(client.getOutputStream());
			String clientSentence = inFromClient.readLine();
			String capitalizedSentence = clientSentence.toUpperCase() + "\n";
			outToClient.writeBytes(capitalizedSentence);			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}