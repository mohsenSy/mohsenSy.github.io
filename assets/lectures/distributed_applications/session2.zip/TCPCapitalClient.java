import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.Socket;

public class TCPCapitalClient {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String sentence, modifiedSentence;
		Socket client = new Socket("localhost", 1234);
		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
		DataOutputStream outToServer = new DataOutputStream(client.getOutputStream());
		BufferedReader inFromServer = new BufferedReader(new InputStreamReader(client.getInputStream()));
		sentence = inFromUser.readLine();
		outToServer.writeBytes(sentence + "\n");
		modifiedSentence = inFromServer.readLine();
		System.out.println("FROM SERVER: " + modifiedSentence);
		client.close();
	}

}
