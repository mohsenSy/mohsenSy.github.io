package session5;

import java.net.InetAddress;

public class Client implements ClientInt, java.io.Serializable {
	private String name;
	private InetAddress ip;
	private int port;
	
	public Client(String name, InetAddress ip, int port) {
		this.name = name;
		this.ip = ip;
		this.port = port;
	}
	
	public void print() {
		System.out.println("name = " + name + " ip = " + ip + " port = " + port);
	}

}
