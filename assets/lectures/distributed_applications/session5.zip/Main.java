package session5;

import java.io.*;
import java.net.*;

public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Client c = new Client("mohsen", InetAddress.getByName("localhost"), 1234);
		FileOutputStream fos = new FileOutputStream("client");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(c);
		oos.close();
		fos.close();
		FileInputStream fis = new FileInputStream("client");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Client cc = (Client)ois.readObject();
		cc.print();
		ois.close();
		fis.close();
	}

}
