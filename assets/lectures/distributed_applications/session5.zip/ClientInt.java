package session5;

public interface ClientInt {
	
	public void print();

}
